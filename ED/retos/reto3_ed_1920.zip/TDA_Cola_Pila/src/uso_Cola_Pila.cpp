/**
 * @file uso_Cola_Pila.cpp
 * @author Daniel Pérez Ruiz // Pablo Nieto López
 * @brief Programa para testear implementación Cola_Pila
 * @date 23/11/19
 * @version 3.0
 */
 
 #include <iostream>
 #include "Cola_Pila.h"
 
 using namespace std;

int main(){
	Cola<char> cola, cola_copia;
	char letra;
        unsigned i=1;
        
        //TEST FUNCION PONER()
        cout << "Inserte frase >>> ";
	while((letra = cin.get()) != '\n'){
            cola.poner(letra);
	}
        
        //TEST OPERADOR =
        cola_copia = cola;
	
        //TEST FUNCION FRENTE() Y QUITAR()
        cout << endl << "La frase introducida es >>> ";
	
        while(cola_copia.size() != 0){
            cout << cola_copia.frente() << " ";
            cola_copia.quitar();
        }
        
        //MOSTRAR ESTRUCTURA COLA
        cout << endl << endl << "ESQUEMA DE COLA:" << endl;
        cout << "Hay un total de [" << cola.size() << "] elementos" << endl;
        cout << "FRENTE DE COLA [0] -> [" << cola.frente() << "]" << endl;
        cola.quitar();
        while(!cola.esta_vacia()){
            cout << "ELEMENTO [" << i << "] >> [" << cola.frente() << "]" << endl;
            i++;
            cola.quitar();
        }
	
	cout << endl;
	
	return 0;
}
