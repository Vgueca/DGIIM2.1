/**
 * @file Pila_Cola.h
 * @author Daniel Pérez Ruiz // Pablo Nieto López
 * @brief Definición del Template Pila
 * @version 3.0
 * @date 23/11/19
 */

#ifndef PILA_COLA_H
#define PILA_COLA_H

#include <stack>

/**
 * @brief T.D.A. Cola
 * 
 * Una instancia @e v del tipo de datos abstracto Cola sobre el tipo @c T es
 * una lista de elementos del mismo con un funcionamiento @e FIFO (First In,
 * First Out). 
 * 
 * Esta Cola está implementada a partir del TDA stack de la STL.
 */

template <class T>
class Cola{
    private:
        std::stack <T> pila;
        
    public:
        /**
         * @brief Constructor por defecto de la clase.
         */
        Cola();
        
        /**
         * @brief Constructor de copia de la clase.
         * @param otra. La cola de la que se hara la copia.
         */
        Cola(const Cola& otra);
        
        /**
         * @brief Sobrecarga del operador de asignación
         * @param otra Cola de la que se hará copia.
         */
        Cola& operator= (const Cola& otra);
            
        /**
         * @brief Comprueba si la pila esta vacia
         * @return True si lo esta, False si no
         */
        bool esta_vacia() const;
        
        /**
         * @brief Añade un elemento al final de la cola
         * @param n Un elemento de tipo T
         */
        void poner(const T &n);
        
        /**
         * @brief Quita el elemento del frente de la cola
         */
        void quitar();
        
        /**
         * @brief Devuelve una copia del frente de la cola
         * @return Una objeto T situado en el frente de la cola
         */
        T frente() const;
        
        /**
         * @brief Devuelve el tamanio de la cola
         */
        unsigned size() const;
};
#include "Cola_Pila.cpp"

#endif /* PILA_COLA_H */

