/**
 * @file Cola_Pila.cpp
 * @author Daniel Pérez Ruiz // Pablo Nieto López
 * @brief Implementación de los métodos de la clase Cola
 * @date 23/11/19
 * @version 3.0
 */

#include <stack>


using namespace std;

/**
 * 1. CONSTRUCTORES DE LA CLASE
 */

template <class T>
Cola<T>::Cola(): pila(){}

template <class T>
Cola<T>::Cola(const Cola& otra): pila(otra.pila){}

template <class T>
Cola<T>& Cola<T>::operator =(const Cola& otra){
    if(this != &otra){
        pila = otra.pila;
    }
    return *this;
}

/**
 * 2. MÉTODOS DE LA COLA
 */

template <class T>
bool Cola<T>::esta_vacia() const{
    return pila.empty();
}

template <class T>
unsigned Cola<T>::size() const{
	return pila.size();
}

template <class T>
void Cola<T>::quitar(){
    stack<T> auxiliar;
    
    while(size() != 1){
        auxiliar.push(pila.top());
        pila.pop();
    }
    pila.pop();
    
    while(!auxiliar.empty()){
        pila.push(auxiliar.top());
        auxiliar.pop();
    }
        
}

template <class T>
void Cola<T>::poner(const T &n){
    pila.push(n);
}

template <class T>
T Cola<T>::frente() const{
	stack<T> auxiliar = pila;
        
        while(auxiliar.size() != 1)
            auxiliar.pop();
        
        return auxiliar.top();
}
